#include "headers.h"

/* Function to print out a linked list*/
void printList(  CONTROL* myList )
{
    NODE* listNode;

    listNode = myList->firstNode;

    printf("\nLinear print out of link list with %d nodes (elements)\n\n", myList->nodeCount);

    << ENTER CODE HERE TO LOOP TO PRINT OUT EACH NODE IN THE ORDER THEY WERE PUT IN THE LIST >>
	<<  i.e.
	       Node: 1: Data Position: 1 Value: A
	>>	   

    printf("\n\n");

}
