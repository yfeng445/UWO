//CS2211a 2020
//Assignment 1
//Yulun Feng
//251113989
//yfeng445
//Sep, 27 ,2020
#include<stdio.h>
int main(){
	printf("Hello World!");
	return 0;
}

