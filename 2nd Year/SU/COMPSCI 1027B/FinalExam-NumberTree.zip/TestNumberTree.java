
public class TestNumberTree {

	public static void main(String[] args) {
		
		
		// Test 1
		
		
		LinkedBinaryTree<Integer> tree1 = createTree1(new int[] {7,5,3,1,3,6,4});
		NumberTree numTree1 = new NumberTree(tree1);
		int r1 = numTree1.compute();
		if (r1 == 21) {
			System.out.println("Test 1 Passed");
		} else {
			System.out.println("Test 1 Failed");
		}
		
		
		// Test 2
	
		
		LinkedBinaryTree<Integer> tree2 = createTree2(new int[] {15,9,4,3,5,7,7,12,10,2,2,25,16,8,5});
		NumberTree numTree2 = new NumberTree(tree2);
		int r2 = numTree2.compute();
		if (r2 == 65) {
			System.out.println("Test 2 Passed");
		} else {
			System.out.println("Test 2 Failed");
		}
		
		
		// Test 3
		
		
		LinkedBinaryTree<Integer> tree3 = createTree3(new int[] {9,-3,3,-8,1,2,-2,-2});
		NumberTree numTree3 = new NumberTree(tree3);
		int r3 = numTree3.compute();
		if (r3 == 9) {
			System.out.println("Test 3 Passed");
		} else {
			System.out.println("Test 3 Failed");
		}
		
	}
	
	
	private static LinkedBinaryTree<Integer> createTree1 (int[] arr) {
		BinaryTreeNode<Integer> root = new BinaryTreeNode<Integer>(arr[0]);
		
		BinaryTreeNode<Integer> n1 = new BinaryTreeNode<Integer>(arr[1]);
		BinaryTreeNode<Integer> n2 = new BinaryTreeNode<Integer>(arr[2]);

		BinaryTreeNode<Integer> n3 = new BinaryTreeNode<Integer>(arr[3]);
		BinaryTreeNode<Integer> n4 = new BinaryTreeNode<Integer>(arr[4]);
		BinaryTreeNode<Integer> n5 = new BinaryTreeNode<Integer>(arr[5]);
		BinaryTreeNode<Integer> n6 = new BinaryTreeNode<Integer>(arr[6]);

		root.setLeft(n1);
		root.setRight(n2);
		
		n1.setLeft(n3);
		n1.setRight(n4);
		n2.setLeft(n5);
		n2.setRight(n6);
		
		LinkedBinaryTree<Integer> tree = new LinkedBinaryTree<Integer>(root);
		
		return tree;
	}
	
	private static LinkedBinaryTree<Integer> createTree2 (int[] arr) {
		BinaryTreeNode<Integer> root = new BinaryTreeNode<Integer>(arr[0]);
		
		BinaryTreeNode<Integer> n1 = new BinaryTreeNode<Integer>(arr[1]);
		BinaryTreeNode<Integer> n2 = new BinaryTreeNode<Integer>(arr[2]);

		BinaryTreeNode<Integer> n3 = new BinaryTreeNode<Integer>(arr[3]);
		BinaryTreeNode<Integer> n4 = new BinaryTreeNode<Integer>(arr[4]);
		BinaryTreeNode<Integer> n5 = new BinaryTreeNode<Integer>(arr[5]);
		BinaryTreeNode<Integer> n6 = new BinaryTreeNode<Integer>(arr[6]);
		
		BinaryTreeNode<Integer> n7 = new BinaryTreeNode<Integer>(arr[7]);
		BinaryTreeNode<Integer> n8 = new BinaryTreeNode<Integer>(arr[8]);
		BinaryTreeNode<Integer> n9 = new BinaryTreeNode<Integer>(arr[9]);
		BinaryTreeNode<Integer> n10 = new BinaryTreeNode<Integer>(arr[10]);
		BinaryTreeNode<Integer> n11 = new BinaryTreeNode<Integer>(arr[11]);
		BinaryTreeNode<Integer> n12 = new BinaryTreeNode<Integer>(arr[12]);
		BinaryTreeNode<Integer> n13 = new BinaryTreeNode<Integer>(arr[13]);
		BinaryTreeNode<Integer> n14 = new BinaryTreeNode<Integer>(arr[14]);

		
		root.setLeft(n1);
		root.setRight(n2);
		
		n1.setLeft(n3);
		n1.setRight(n4);
		n2.setLeft(n5);
		n2.setRight(n6);
		
		n3.setLeft(n7);
		n3.setRight(n8);
		n4.setLeft(n9);
		n4.setRight(n10);
		n5.setLeft(n11);
		n5.setRight(n12);
		n6.setLeft(n13);
		n6.setRight(n14);
		
		LinkedBinaryTree<Integer> tree = new LinkedBinaryTree<Integer>(root);
		
		return tree;
	}
	
	
	private static LinkedBinaryTree<Integer> createTree3 (int[] arr) {
		BinaryTreeNode<Integer> root = new BinaryTreeNode<Integer>(arr[0]);
		
		BinaryTreeNode<Integer> n1 = new BinaryTreeNode<Integer>(arr[1]);
		BinaryTreeNode<Integer> n2 = new BinaryTreeNode<Integer>(arr[2]);

		BinaryTreeNode<Integer> n3 = new BinaryTreeNode<Integer>(arr[3]);
		BinaryTreeNode<Integer> n4 = new BinaryTreeNode<Integer>(arr[4]);
		
		BinaryTreeNode<Integer> n5 = new BinaryTreeNode<Integer>(arr[5]);
		BinaryTreeNode<Integer> n6 = new BinaryTreeNode<Integer>(arr[6]);
		BinaryTreeNode<Integer> n7 = new BinaryTreeNode<Integer>(arr[7]);

		root.setLeft(n1);
		root.setRight(n2);
		
		n1.setLeft(n3);
		n2.setRight(n4);
		
		n3.setRight(n5);
		n4.setLeft(n6);
		n4.setRight(n7);
		
		LinkedBinaryTree<Integer> tree = new LinkedBinaryTree<Integer>(root);
		
		return tree;
	}

}
