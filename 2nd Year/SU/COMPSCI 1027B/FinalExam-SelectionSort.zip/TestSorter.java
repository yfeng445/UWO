
public class TestSorter {

	public static void main(String[] args) {
		
		String res;
		
		
		// Test 1
		
		
		Sorter<Integer> iSort = new Sorter<Integer>(new Integer[] {94, 74, 37, 6, 12, 130, 42, 89, 107, 37, 55, 125, 22, 63});
		CircularArrayQueue<Integer> iRes = iSort.sort();
		res = iRes.toString();
		
		if (res.equals("6, 12, 22, 37, 37, 42, 55, 63, 74, 89, 94, 107, 125, 130.")) {
			System.out.println("Test 1 Passed");
		} else {
			System.out.println("Test 1 Failed");
		}

		
		// Test 2
		
		
		Sorter<String> sSort = new Sorter<String>(new String[] {"elephant", "monkey", "hippo", "zebra", "lion", "rhino", "monkey"});
		CircularArrayQueue<String> sRes = sSort.sort();
		res = sRes.toString();
		
		if (res.equals("elephant, hippo, lion, monkey, monkey, rhino, zebra.")) {
			System.out.println("Test 2 Passed");
		} else {
			System.out.println("Test 2 Failed");
		}
		
		
		// Test 3

		
		Sorter<Movie> mSort = new Sorter<Movie>(new Movie[] {
				new Movie("Avatar", 9.0),
				new Movie("Titanic", 7.6),
				new Movie("Superbad", 6.2),
				new Movie("Gone Girl", 8.1),
				new Movie("The Lion King", 7.1),
				new Movie("Deadpool", 6.1),
				new Movie("Jurassic Park", 5.6)
		});
		CircularArrayQueue<Movie> mRes = mSort.sort();
		res = mRes.toString();
		
		if (res.equals("Jurassic Park, Deadpool, Superbad, The Lion King, Titanic, Gone Girl, Avatar.")) {
			System.out.println("Test 3 Passed");
		} else {
			System.out.println("Test 3 Failed");
		}
		

	}

}
