
public class CircularArrayQueue<T> implements QueueADT<T> {

    private int front; //pointer to head of queue
    private int rear; //pointer to tail of queue
    private int count; //keeps track of size of queue
    private T[] myQueue; //queue of generic type
    private final int DEFAULT_CAPACITY = 20; //the max size of circular queue

    //creates an empty queue initialize to default values
    public CircularArrayQueue() {

        front = 1;
        rear = DEFAULT_CAPACITY;
        count = 0;
        myQueue = (T[]) (new Object[DEFAULT_CAPACITY]);
    }

    //creates an empty queue initialized with a passed capacity param
    public CircularArrayQueue(int initialCapacity) {

        front = 1;
        rear = initialCapacity;
        count = 0;
        myQueue = (T[]) (new Object[initialCapacity]);

    }

    public void enqueue(T item) {
        if (count == myQueue.length) {
            expandCapacity();
        }
        rear = (rear + 1) % myQueue.length;
        myQueue[rear] = item;
        count++;
    }

    public T dequeue() throws EmptyCollectionException {
        if (isEmpty()) {
            throw new EmptyCollectionException("Empty queue");
        }
        T dequeuedItem = myQueue[front];
        myQueue[front] = null;
        front = (front + 1) % myQueue.length;
        count--;
        return dequeuedItem;
    }

    public T first() throws EmptyCollectionException {
        if (isEmpty()) {
            throw new EmptyCollectionException("Empty queue");
        }
        return myQueue[front];
    }

    public boolean isEmpty() {
        return (count == 0);
    }

    public int size() {
        return count;
    }

    public int getFront() {
        return front;
    }

    public int getRear() {
        return rear;
    }

    public int getLength() {
        return myQueue.length;
    }

    public String toString() {
        if (isEmpty()) {
            return "The queue is empty";
        }
        String toStr = "";
        for (int i = 0, j = front; i < count; i++) {
            toStr += myQueue[j];
            j = (j + 1) % myQueue.length;
            if (i < count - 1) {
                toStr += ", ";
            }
        }
        toStr += ".";
        return toStr;
    }

    private void expandCapacity() {

        T[] biggerArray = (T[]) (new Object[myQueue.length + DEFAULT_CAPACITY]);
        for (int i = 1; i <= count; i++) {
            biggerArray[i] = myQueue[front];
            front = (front + 1) % myQueue.length;
        }
        front = 1;
        rear = count;
        myQueue = biggerArray;
    }

}
