
public class Movie implements Comparable<Movie> {
	
	private String title;
	private double rating;
	
	public Movie (String title, double rating) {
		this.title = title;
		this.rating = rating;
	}
	
	public String getTitle () {
		return title;
	}
	
	public double getRating () {
		return rating;
	}
	
	public int compareTo (Movie otherMovie) {
		if (this.rating < otherMovie.getRating()) {
			return -1;
		} else if (this.rating > otherMovie.getRating()) {
			return 1;
		} else {
			return 0;
		}
	}
	
	public String toString () {
		return title;
	}

}
